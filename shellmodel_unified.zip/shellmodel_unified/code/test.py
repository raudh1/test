from shellmodels_lib import *
from libraries import *


mlp=MLP(100,12,1,25,0)
optimizer=th.optim.Adam(mlp.parameters(),lr=0.001)
data=load_data('./dataset/N12/','Uf_N12.npy')
train_set,valid,test=split_data(data)

standard=STDtraining(mlp,optimizer,train_set,valid)

standard.train(mlp,optimizer,train_set,valid,10,10,save=False)

print(standard)
#forecast=FORtraining()

